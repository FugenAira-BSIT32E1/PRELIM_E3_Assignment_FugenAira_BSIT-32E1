﻿namespace PRELIM_E3_Assignment_FugenAira_BSIT_32E1.Models
{
    public class School
    {
        public int Schedule { get; set; }
        public String Day { get; set; }
        public int Time { get; set; }

    }
}
